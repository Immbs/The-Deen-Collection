/* ==========================================================================
   The Deen Collection — main.js
   ফর্ম ভ্যালিডেশন, স্মুথ স্ক্রলিং, স্ক্রল-রিভিল ইফেক্ট, প্যাকেজ সিলেকশন, পরিমাণ/টোটাল ও সাকসেস পপআপ
   --------------------------------------------------------------------------
   ব্যাকএন্ড কানেক্ট করতে: নিচে "submitOrder" ফাংশনে fetch() বসান।
   ========================================================================== */
(() => {
  'use strict';

  /* ---------- প্যাকেজ ডেটা ----------
     দাম/পণ্য বদলাতে হলে এখানে এবং index.html-এর প্যাকেজ কার্ড ও তুলনা টেবিলে একসাথে বদলান। */
  const PACKAGES = {
    basic: {
      name: 'বেসিক', en: 'Basic Gift Package', price: 799, mrp: 1410, img: 'package-basic',
      items: [
        "জায়নামাজ",
        "সাদা পাথরের ১০০ দানার তাসবীহ",
        "কালো টুপি",
        "প্রাকৃতিক মেসওয়াক",
        "৬টি ভিন্ন সুবাসের আতর (৬ মিলি করে)"
      ],
      gifts: [
        "মিনি কাঠের তাসবীহ (৩৩ দানা)"
      ]
    },
    standard: {
      name: 'স্ট্যান্ডার্ড', en: 'Standard Gift Package', price: 999, mrp: 1750, img: 'package-standard',
      items: [
        "বড় সাইজের জায়নামাজ",
        "সাদা পাথরের ১০০ দানার তাসবীহ",
        "জাবাল কুফি টুপি",
        "প্রাকৃতিক মেসওয়াক",
        "৬টি ভিন্ন সুবাসের আতর (৬ মিলি করে)"
      ],
      gifts: [
        "মিনি কাঠের তাসবীহ (৩৩ দানা)",
        "ডিজিটাল তাসবীহ কাউন্টার"
      ]
    },
    premium: {
      name: 'প্রিমিয়াম', en: 'Premium Gift Package', price: 1230, mrp: 2060, img: 'package-premium',
      items: [
        "অরিজিনাল টার্কিশ জায়নামাজ",
        "সাদা পাথরের ১০০ দানার তাসবীহ",
        "সাদা মিনার-স্টাইল টুপি",
        "প্রাকৃতিক মেসওয়াক",
        "৬টি ভিন্ন সুবাসের আতর (৬ মিলি করে)"
      ],
      gifts: [
        "মিনি কাঠের তাসবীহ (৩৩ দানা)",
        "LED ডিজিটাল তাসবীহ কাউন্টার",
        "সুরমা"
      ]
    }
  };
  const DEFAULT_PKG = 'standard';
  const MAX_QTY = 10;
  let qty = 1;
  let currentPkg = DEFAULT_PKG;
  let userPicked = false;   // ব্যবহারকারী নিজে প্যাকেজ বেছে নিয়েছেন কি না (মোবাইল CTA-র জন্য)

  /* ---------- Helpers ---------- */
  const bnDigits = ['০','১','২','৩','৪','৫','৬','৭','৮','৯'];
  const toBn = n => String(n).replace(/\d/g, d => bnDigits[d]);
  const toEn = s => String(s).replace(/[০-৯]/g, d => bnDigits.indexOf(d));
  const fmtBn = n => toBn(n.toLocaleString('en-IN'));
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];

  $('#year').textContent = toBn(new Date().getFullYear());

  /* ---------- Top bar ticker (train-style continuous scroll) ----------
     দুইটি একই রকম গ্রুপ পাশাপাশি থাকে; ট্র্যাক -৫০% সরে গেলে লুপ নিখুঁতভাবে মিলে যায়।
     স্ক্রিন যত চওড়াই হোক, গ্রুপটি যেন ফাঁকা না দেখায় সেজন্য প্রয়োজনমতো আইটেম ক্লোন করা হয়,
     আর গতি (px/সেকেন্ড) সব স্ক্রিনে একই রাখা হয়। */
  const TICKER_SPEED = 55; // px per second
  const ticker = $('#ticker');
  if (ticker) {
    const track = $('.ticker-track', ticker);
    const [groupA, groupB] = $$('.ticker-group', track);
    const templates = [...groupA.children].map(li => li.cloneNode(true)); // সব ভিন্ন মেসেজ

    const buildTicker = () => {
      // keep group A at least as wide as the visible area (repeat the full message set)
      let guard = 0;
      while (groupA.scrollWidth < ticker.clientWidth + 50 && guard++ < 50) {
        templates.forEach(t => groupA.appendChild(t.cloneNode(true)));
      }
      // mirror A into B for a seamless loop
      groupB.innerHTML = groupA.innerHTML;
      const duration = groupA.scrollWidth / TICKER_SPEED;
      track.style.setProperty('--ticker-duration', duration.toFixed(2) + 's');
    };

    buildTicker();
    let resizeTimer;
    window.addEventListener('resize', () => {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(buildTicker, 200);
    });
    // re-measure once web fonts are ready (text width changes)
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(buildTicker);
  }

  /* ---------- Smooth scroll to order form ---------- */
  const orderSection = $('#order');
  const scrollToOrder = (e) => {
    e && e.preventDefault();
    const navH = $('#navbar').offsetHeight;
    const y = orderSection.getBoundingClientRect().top + window.pageYOffset - navH - 8;
    window.scrollTo({ top: y, behavior: 'smooth' });
    // Focus the first field after scrolling (without jumping)
    setTimeout(() => $('#name').focus({ preventScroll: true }), 750);
  };
  $$('.js-order').forEach(btn => btn.addEventListener('click', scrollToOrder));

  // Smooth scroll for other in-page links (offset for sticky nav)
  $$('a[href^="#"]:not(.js-order)').forEach(a => {
    a.addEventListener('click', e => {
      const id = a.getAttribute('href');
      const target = id === '#top' ? document.body : $(id);
      if (!target) return;
      e.preventDefault();
      const y = id === '#top' ? 0 : target.getBoundingClientRect().top + window.pageYOffset - $('#navbar').offsetHeight - 8;
      window.scrollTo({ top: y, behavior: 'smooth' });
    });
  });

  /* ---------- Navbar shadow on scroll ---------- */
  const navbar = $('#navbar');
  const onScroll = () => navbar.classList.toggle('scrolled', window.scrollY > 10);
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* ---------- Reveal on scroll ---------- */
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver(entries => {
      entries.forEach(en => { if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); } });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
    $$('.reveal').forEach(el => io.observe(el));

    // Hide mobile sticky CTA while order form is visible
    const cta = $('#mobileCta');
    new IntersectionObserver(([en]) => cta.classList.toggle('hide', en.isIntersecting), { threshold: 0.15 })
      .observe(orderSection);
  } else {
    $$('.reveal').forEach(el => el.classList.add('in'));
  }


  /* ---------- Delivery area (চার্জ/সময় আসে index.html-এর রেডিওর data-* থেকে) ---------- */
  const getArea = () => {
    const r = document.querySelector('input[name="area"]:checked');
    return r ? { id: r.value, label: r.dataset.label, charge: Number(r.dataset.charge), eta: r.dataset.eta } : null;
  };
  const areaField = () => document.querySelector('.field[data-field="area"]');
  const setAreaError = msg => {
    const f = areaField(); if (!f) return;
    f.classList.toggle('invalid', !!msg);
    f.classList.toggle('valid', !msg);
    f.querySelector('.error-msg').textContent = msg;
  };

  /* ---------- Quantity & total ---------- */
  const updateTotal = () => {
    const p = PACKAGES[currentPkg];
    $('#qtyVal').textContent = toBn(qty);
    const area = getArea();
    const sub = p.price * qty;
    $$('.js-subtotal').forEach(el => el.textContent = fmtBn(sub));
    $$('.js-total').forEach(el => el.textContent = fmtBn(sub + (area ? area.charge : 0)));
    $$('.js-delivery').forEach(el => el.textContent = area ? fmtBn(area.charge) + ' টাকা' : 'এলাকা বেছে নিন');
    $$('.js-mrp').forEach(el => el.textContent = fmtBn(p.mrp * qty));
    $$('.js-save').forEach(el => el.textContent = fmtBn((p.mrp - p.price) * qty));
    $('#qtyMinus').disabled = qty <= 1;
    $('#qtyPlus').disabled = qty >= MAX_QTY;
  };
  $('#qtyMinus').addEventListener('click', () => { if (qty > 1) { qty--; updateTotal(); } });
  $('#qtyPlus').addEventListener('click', () => { if (qty < MAX_QTY) { qty++; updateTotal(); } });

  /* ---------- Package selection ---------- */
  const ICON = id => `<svg><use href="#i-${id}"/></svg>`;
  const UPSELL = {
    basic: {
      to: 'standard',
      text: 'মাত্র <b>২০০ টাকা বেশি</b> দিলেই স্ট্যান্ডার্ড — বড় জায়নামাজ, জাবাল কুফি টুপি আর <b>ডিজিটাল তাসবীহ কাউন্টার ফ্রি!</b>',
      btn: 'স্ট্যান্ডার্ড নিন'
    },
    standard: {
      to: 'premium',
      text: 'আর মাত্র <b>২৩১ টাকায়</b> প্রিমিয়াম — টার্কিশ জায়নামাজ, মিনার-স্টাইল টুপি, <b>LED তাসবীহ ও সুরমা ফ্রি!</b>',
      btn: 'প্রিমিয়াম নিন'
    }
  };
  const upsell = $('#upsell');

  function selectPackage(id, { explicit = false } = {}) {
    if (!PACKAGES[id]) return;
    currentPkg = id;
    const p = PACKAGES[id];

    const radio = $(`input[name="package"][value="${id}"]`);
    if (radio) radio.checked = true;

    // summary
    const img = $('#sumImg'), webp = $('#sumImgWebp');
    if (webp) webp.srcset = `assets/images/${p.img}.webp`;
    if (img) { img.src = `assets/images/${p.img}.jpg`; img.alt = `${p.name} গিফট প্যাকেজ`; }
    $('#sumName').textContent = `${p.name} গিফট প্যাকেজ`;
    $('#sumSub').innerHTML = `${p.en} · <span class="nowrap">১ এর ভেতর ৫</span> + ${toBn(p.gifts.length)}টি ফ্রি উপহার`;
    $('#sumItems').innerHTML =
      p.items.map(n => `<li>${ICON('check')}${n}</li>`).join('') +
      p.gifts.map(n => `<li class="gift">${ICON('gift')}${n} (ফ্রি)</li>`).join('');

    // upsell
    const u = UPSELL[id];
    if (u) {
      $('#upsellText').innerHTML = u.text;
      $('#upsellBtn').textContent = u.btn;
      $('#upsellBtn').dataset.to = u.to;
      upsell.hidden = false;
    } else {
      upsell.hidden = true;
    }

    // mobile sticky CTA
    if (explicit) userPicked = true;
    if (userPicked) {
      $('#mcLabel').textContent = p.name;
      $('#mcPrice').textContent = fmtBn(p.price) + ' ৳';
    }
    updateTotal();
  }

  $$('input[name="area"]').forEach(r => r.addEventListener('change', () => { setAreaError(''); updateTotal(); }));
  $$('input[name="package"]').forEach(r =>
    r.addEventListener('change', () => r.checked && selectPackage(r.value, { explicit: true })));
  $('#upsellBtn').addEventListener('click', e => selectPackage(e.currentTarget.dataset.to, { explicit: true }));

  // প্যাকেজ কার্ড / তুলনা টেবিল / গাইডের বাটন → প্যাকেজ সিলেক্ট করে অর্ডার ফর্মে যায়
  document.addEventListener('click', e => {
    const btn = e.target.closest('[data-select]');
    if (!btn) return;
    selectPackage(btn.dataset.select, { explicit: true });
    scrollToOrder(e);
  });

  // প্রোডাক্ট পেজ থেকে "?package=basic#order" লিংকে এলে সেই প্যাকেজটি আগে থেকেই সিলেক্ট থাকবে
  const urlPkg = new URLSearchParams(location.search).get('package');
  const initial = $('input[name="package"]:checked');
  if (PACKAGES[urlPkg]) selectPackage(urlPkg, { explicit: true });
  else selectPackage(initial ? initial.value : DEFAULT_PKG);

  /* ---------- Packages carousel (mobile/tablet): tabs ↔ swipe ---------- */
  const pkgGrid = $('#pkgGrid');
  const pkgTabs = $$('.pkg-tab');
  if (pkgGrid && pkgTabs.length) {
    const cards = $$('.pkg-card', pkgGrid);
    const isCarousel = () => pkgGrid.scrollWidth > pkgGrid.clientWidth + 4;
    const centerOn = (card, smooth) => {
      const left = card.offsetLeft - (pkgGrid.clientWidth - card.offsetWidth) / 2;
      pkgGrid.scrollTo({ left, behavior: smooth ? 'smooth' : 'auto' });
    };
    const setActive = id => pkgTabs.forEach(t => {
      const on = t.dataset.target === id;
      t.classList.toggle('active', on);
      t.setAttribute('aria-pressed', on);
    });
    pkgTabs.forEach(t => t.addEventListener('click', () => {
      setActive(t.dataset.target);
      centerOn($('#pkg-' + t.dataset.target), true);
    }));
    let raf;
    pkgGrid.addEventListener('scroll', () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const mid = pkgGrid.scrollLeft + pkgGrid.clientWidth / 2;
        let best = cards[0], dist = Infinity;
        cards.forEach(c => {
          const d = Math.abs(c.offsetLeft + c.offsetWidth / 2 - mid);
          if (d < dist) { dist = d; best = c; }
        });
        setActive(best.dataset.pkg);
      });
    }, { passive: true });
    // শুরুতে জনপ্রিয় (স্ট্যান্ডার্ড) প্যাকেজটি মাঝখানে দেখাও
    const initCarousel = () => { if (isCarousel()) centerOn($('#pkg-' + DEFAULT_PKG), false); };
    initCarousel();
    window.addEventListener('load', initCarousel);
    setActive(DEFAULT_PKG);
  }

  /* ---------- Form validation ---------- */
  const form = $('#orderForm');
  const fields = {
    name: {
      el: $('#name'),
      validate: v => {
        v = v.trim();
        if (!v) return 'অনুগ্রহ করে আপনার নাম লিখুন';
        if (v.length < 3) return 'নাম কমপক্ষে ৩ অক্ষরের হতে হবে';
        return '';
      }
    },
    phone: {
      el: $('#phone'),
      validate: v => {
        const num = toEn(v).replace(/[\s-]/g, '').replace(/^(\+?88)/, '');
        if (!num) return 'অনুগ্রহ করে মোবাইল নম্বর লিখুন';
        if (!/^01[3-9]\d{8}$/.test(num)) return 'সঠিক ১১ ডিজিটের মোবাইল নম্বর দিন (যেমন: 01712345678)';
        return '';
      }
    },
    address: {
      el: $('#address'),
      validate: v => {
        v = v.trim();
        if (!v) return 'অনুগ্রহ করে সম্পূর্ণ ঠিকানা লিখুন';
        if (v.length < 10) return 'ঠিকানাটি আরও বিস্তারিত লিখুন (এলাকা, থানা, জেলা)';
        return '';
      }
    }
  };

  const setState = (key, msg) => {
    const wrap = fields[key].el.closest('.field');
    wrap.classList.toggle('invalid', !!msg);
    wrap.classList.toggle('valid', !msg);
    $('.error-msg', wrap).textContent = msg;
    fields[key].el.setAttribute('aria-invalid', !!msg);
  };

  Object.keys(fields).forEach(key => {
    const f = fields[key];
    f.el.addEventListener('blur', () => { if (f.el.value) setState(key, f.validate(f.el.value)); });
    f.el.addEventListener('input', () => {
      const wrap = f.el.closest('.field');
      if (wrap.classList.contains('invalid') || wrap.classList.contains('valid')) setState(key, f.validate(f.el.value));
    });
  });

  // Phone: allow only digits (Bangla/English), +, space, dash
  $('#phone').addEventListener('input', e => {
    e.target.value = e.target.value.replace(/[^\d০-৯+\s-]/g, '');
  });

  const submitBtn = $('#submitBtn');
  const btnOriginal = submitBtn.innerHTML;

  form.addEventListener('submit', e => {
    e.preventDefault();
    let firstInvalid = null;

    Object.keys(fields).forEach(key => {
      const msg = fields[key].validate(fields[key].el.value);
      setState(key, msg);
      if (msg && !firstInvalid) firstInvalid = key;
    });

    const areaSel = getArea();
    if (!firstInvalid && !areaSel) {
      setAreaError('অনুগ্রহ করে ডেলিভারি এলাকা নির্বাচন করুন');
      const f = areaField();
      f.classList.remove('shake'); void f.offsetWidth; f.classList.add('shake');
      $('input[name="area"]').focus();
      return;
    }
    if (firstInvalid) {
      const wrap = fields[firstInvalid].el.closest('.field');
      wrap.classList.remove('shake'); void wrap.offsetWidth; wrap.classList.add('shake');
      fields[firstInvalid].el.focus();
      return;
    }

    // Simulate sending the order (replace with real fetch() to your backend / Google Sheet / etc.)
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span class="spinner"></span><span>অর্ডার প্রসেস হচ্ছে...</span>';

    const pkg = PACKAGES[currentPkg];
    const order = {
      id: 'TDC-' + Date.now().toString().slice(-6),
      name: fields.name.el.value.trim(),
      phone: toEn(fields.phone.el.value).replace(/[\s-]/g, '').replace(/^(\+?88)/, ''),
      address: fields.address.el.value.trim(),
      package: currentPkg,
      title: pkg.name + ' গিফট প্যাকেজ',
      subtitle: pkg.en + ' · ১ এর ভেতর ৫ + ' + toBn(pkg.gifts.length) + 'টি ফ্রি উপহার',
      mrp: pkg.mrp,
      lines: pkg.items.map(n => ({ name: n })).concat(pkg.gifts.map(n => ({ name: n, gift: true }))),
      packageName: pkg.en,
      unitPrice: pkg.price,
      qty,
      subtotal: pkg.price * qty,
      deliveryArea: areaSel.id,
      deliveryLabel: areaSel.label,
      deliveryEta: areaSel.eta,
      deliveryCharge: areaSel.charge,
      total: pkg.price * qty + areaSel.charge,
      product: pkg.en
    };

    submitOrder(order)
      .then(() => showModal(order))
      .catch(() => alert('দুঃখিত, অর্ডারটি পাঠানো যায়নি। অনুগ্রহ করে আবার চেষ্টা করুন।'))
      .finally(() => {
        submitBtn.disabled = false;
        submitBtn.innerHTML = btnOriginal;
        updateTotal();
      });
  });

  /* ---------- Send order ----------
     এখন এটি শুধু ডেমো (১.২ সেকেন্ড অপেক্ষা করে সফল দেখায়)।
     আসল ব্যাকএন্ডের জন্য নিচের মতো fetch() ব্যবহার করুন:

       return fetch('/api/orders', {
         method: 'POST',
         headers: { 'Content-Type': 'application/json' },
         body: JSON.stringify(order)
       }).then(r => { if (!r.ok) throw new Error('Order failed'); return r.json(); });
  */
  function submitOrder(order) {
    console.log('New order:', order);
    return new Promise(resolve => setTimeout(resolve, 1200));
  }

  /* ---------- Success modal ---------- */
  const modal = $('#successModal');
  let lastFocus = null;
  let lastOrder = null;

  function showModal(o) {
    lastOrder = o;
    $('#mId').textContent = '#' + o.id;            // English digits
    $('#mName').textContent = o.name;
    $('#mPhone').textContent = o.phone;            // English digits
    $('#mPkg').textContent = PACKAGES[o.package].name + ' গিফট প্যাকেজ';
    $('#mQty').textContent = toBn(o.qty) + 'টি প্যাকেজ';
    $('#mTotal').textContent = fmtBn(o.total) + ' টাকা';
    lastFocus = document.activeElement;
    modal.classList.add('open');
    modal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    setTimeout(() => $('#modalOk').focus(), 300);
  }

  function closeModal() {
    modal.classList.remove('open');
    modal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    form.reset();
    qty = 1;
    const def = $('input[name="package"]:checked');
    selectPackage(def ? def.value : DEFAULT_PKG);
    $$('.field', form).forEach(f => f.classList.remove('valid', 'invalid'));
    setAreaError(''); areaField().classList.remove('valid');
    lastFocus && lastFocus.blur();
  }

  $('#modalClose').addEventListener('click', closeModal);
  // "ঠিক আছে" → পপআপ বন্ধ + ইনভয়েস (PDF) ডাউনলোড
  $('#modalOk').addEventListener('click', () => {
    const o = lastOrder;
    closeModal();
    if (o && window.TDCInvoice) window.TDCInvoice.download(o, { base: '' });
  });
  modal.addEventListener('click', e => { if (e.target === modal) closeModal(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && modal.classList.contains('open')) closeModal(); });
})();
