/* ==========================================================================
   The Deen Collection — product.js  (products/*.html)
   গ্যালারি, ধরন (ভ্যারিয়েন্ট) বাছাই, পরিমাণ/টোটাল, ট্যাব, অর্ডার ফর্ম ও সাকসেস পপআপ
   --------------------------------------------------------------------------
   পণ্যের ডেটা আসে পেজের <script id="productData"> থেকে।
   ব্যাকএন্ড কানেক্ট করতে: নিচে "submitOrder" ফাংশনে fetch() বসান।
   ========================================================================== */
(() => {
  'use strict';

  const DATA = JSON.parse(document.getElementById('productData').textContent);
  const MAX_QTY = 10;
  let qty = 1;
  let variant = DATA.variants[0];

  /* ---------- Helpers ---------- */
  const bnDigits = ['০','১','২','৩','৪','৫','৬','৭','৮','৯'];
  const toBn = n => String(n).replace(/\d/g, d => bnDigits[d]);
  const toEn = s => String(s).replace(/[০-৯]/g, d => bnDigits.indexOf(d));
  const fmtBn = n => toBn(n.toLocaleString('en-IN'));
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];
  const navH = () => $('#navbar').offsetHeight;

  $('#year').textContent = toBn(new Date().getFullYear());

  /* ---------- Top bar ticker (same behaviour as the home page) ---------- */
  const TICKER_SPEED = 55; // px per second
  const ticker = $('#ticker');
  if (ticker) {
    const track = $('.ticker-track', ticker);
    const [groupA, groupB] = $$('.ticker-group', track);
    const templates = [...groupA.children].map(li => li.cloneNode(true));
    const buildTicker = () => {
      let guard = 0;
      while (groupA.scrollWidth < ticker.clientWidth + 50 && guard++ < 50) {
        templates.forEach(t => groupA.appendChild(t.cloneNode(true)));
      }
      groupB.innerHTML = groupA.innerHTML;
      track.style.setProperty('--ticker-duration', (groupA.scrollWidth / TICKER_SPEED).toFixed(2) + 's');
    };
    buildTicker();
    let rt;
    window.addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(buildTicker, 200); });
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(buildTicker);
  }

  /* ---------- Smooth scrolling ---------- */
  const orderSection = $('#order');
  const scrollToY = y => window.scrollTo({ top: y, behavior: 'smooth' });
  const scrollToOrder = e => {
    e && e.preventDefault();
    scrollToY(orderSection.getBoundingClientRect().top + window.pageYOffset - navH() - 8);
    setTimeout(() => $('#name').focus({ preventScroll: true }), 750);
  };
  $$('.js-order').forEach(b => b.addEventListener('click', scrollToOrder));
  $$('a[href^="#"]:not(.js-order)').forEach(a => a.addEventListener('click', e => {
    const target = $(a.getAttribute('href'));
    if (!target) return;
    e.preventDefault();
    scrollToY(target.getBoundingClientRect().top + window.pageYOffset - navH() - 8);
  }));

  /* ---------- Navbar shadow + reveal ---------- */
  const navbar = $('#navbar');
  const onScroll = () => navbar.classList.toggle('scrolled', window.scrollY > 10);
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver(entries => {
      entries.forEach(en => { if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); } });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
    $$('.reveal').forEach(el => io.observe(el));
    const cta = $('#mobileCta');
    new IntersectionObserver(([en]) => cta.classList.toggle('hide', en.isIntersecting), { threshold: 0.15 })
      .observe(orderSection);
  } else {
    $$('.reveal').forEach(el => el.classList.add('in'));
  }

  /* ---------- Gallery ---------- */
  const mainImg = $('#pdMainImg');
  const mainSrc = $('#pdMainSrc');
  const cap = $('#pdCap');
  $$('.pd-thumb').forEach(btn => btn.addEventListener('click', () => {
    if (btn.classList.contains('active')) return;
    $$('.pd-thumb').forEach(t => t.classList.toggle('active', t === btn));
    const d = btn.dataset;
    mainImg.classList.add('swap');
    setTimeout(() => {
      mainSrc.srcset = `../assets/images/${d.img}.webp`;
      mainImg.src = `../assets/images/${d.img}.${d.ext}`;
      mainImg.width = d.w; mainImg.height = d.h;
      mainImg.alt = d.alt;
      mainImg.closest('.pd-main').classList.toggle('is-portrait', +d.h > +d.w);
      cap.textContent = d.cap;
      const show = () => mainImg.classList.remove('swap');
      if (mainImg.complete) requestAnimationFrame(show); else mainImg.onload = show;
    }, 180);
  }));


  /* ---------- Delivery area (চার্জ/সময় আসে index.html-এর রেডিওর data-* থেকে) ---------- */
  const getArea = () => {
    const r = document.querySelector('input[name="area"]:checked');
    return r ? { id: r.value, label: r.dataset.label, charge: Number(r.dataset.charge), eta: r.dataset.eta } : null;
  };
  const areaField = () => document.querySelector('.field[data-field="area"]');
  const setAreaError = msg => {
    const f = areaField(); if (!f) return;
    f.classList.toggle('invalid', !!msg);
    f.classList.toggle('valid', !msg);
    f.querySelector('.error-msg').textContent = msg;
  };

  /* ---------- Variant + quantity + totals ---------- */
  const update = () => {
    $$('.js-unit').forEach(el => el.textContent = fmtBn(variant.price));
    const area = getArea();
    const sub = variant.price * qty;
    $$('.js-subtotal').forEach(el => el.textContent = fmtBn(sub));
    $$('.js-total').forEach(el => el.textContent = fmtBn(sub + (area ? area.charge : 0)));
    $$('.js-delivery').forEach(el => el.textContent = area ? fmtBn(area.charge) + ' টাকা' : 'এলাকা বেছে নিন');
    $$('.js-qty').forEach(el => el.textContent = toBn(qty));
    $$('[data-qty="-1"]').forEach(b => b.disabled = qty <= 1);
    $$('[data-qty="1"]').forEach(b => b.disabled = qty >= MAX_QTY);
    $('#pdVarLabel').textContent = variant.label;
    $('#sumVariant').textContent = `${variant.label} · ${variant.note}`;
    $('#mcLabel').textContent = variant.label;
  };
  $$('input[name="variant"]').forEach(r => r.addEventListener('change', () => {
    if (!r.checked) return;
    variant = DATA.variants.find(v => v.id === r.value) || DATA.variants[0];
    update();
  }));
  $$('input[name="area"]').forEach(r => r.addEventListener('change', () => { setAreaError(''); update(); }));
  $$('[data-qty]').forEach(b => b.addEventListener('click', () => {
    qty = Math.min(MAX_QTY, Math.max(1, qty + Number(b.dataset.qty)));
    update();
  }));
  const checked = $('input[name="variant"]:checked');
  if (checked) variant = DATA.variants.find(v => v.id === checked.value) || variant;
  update();

  /* ---------- Tabs (keyboard accessible) ---------- */
  const tabs = $$('.pd-tabs [role="tab"]');
  const activate = tab => {
    tabs.forEach(t => {
      const on = t === tab;
      t.setAttribute('aria-selected', on);
      t.tabIndex = on ? 0 : -1;
      $('#' + t.getAttribute('aria-controls')).hidden = !on;
    });
  };
  tabs.forEach((t, i) => {
    t.addEventListener('click', () => activate(t));
    t.addEventListener('keydown', e => {
      const dir = e.key === 'ArrowRight' ? 1 : e.key === 'ArrowLeft' ? -1 : 0;
      if (!dir) return;
      const next = tabs[(i + dir + tabs.length) % tabs.length];
      activate(next); next.focus();
    });
  });

  /* ---------- Form validation ---------- */
  const form = $('#orderForm');
  const fields = {
    name: { el: $('#name'), validate: v => {
      v = v.trim();
      if (!v) return 'অনুগ্রহ করে আপনার নাম লিখুন';
      if (v.length < 3) return 'নাম কমপক্ষে ৩ অক্ষরের হতে হবে';
      return '';
    } },
    phone: { el: $('#phone'), validate: v => {
      const num = toEn(v).replace(/[\s-]/g, '').replace(/^(\+?88)/, '');
      if (!num) return 'অনুগ্রহ করে মোবাইল নম্বর লিখুন';
      if (!/^01[3-9]\d{8}$/.test(num)) return 'সঠিক ১১ ডিজিটের মোবাইল নম্বর দিন (যেমন: 01712345678)';
      return '';
    } },
    address: { el: $('#address'), validate: v => {
      v = v.trim();
      if (!v) return 'অনুগ্রহ করে সম্পূর্ণ ঠিকানা লিখুন';
      if (v.length < 10) return 'ঠিকানাটি আরও বিস্তারিত লিখুন (এলাকা, থানা, জেলা)';
      return '';
    } }
  };
  const setState = (key, msg) => {
    const wrap = fields[key].el.closest('.field');
    wrap.classList.toggle('invalid', !!msg);
    wrap.classList.toggle('valid', !msg);
    $('.error-msg', wrap).textContent = msg;
    fields[key].el.setAttribute('aria-invalid', !!msg);
  };
  Object.keys(fields).forEach(key => {
    const f = fields[key];
    f.el.addEventListener('blur', () => { if (f.el.value) setState(key, f.validate(f.el.value)); });
    f.el.addEventListener('input', () => {
      const wrap = f.el.closest('.field');
      if (wrap.classList.contains('invalid') || wrap.classList.contains('valid')) setState(key, f.validate(f.el.value));
    });
  });
  $('#phone').addEventListener('input', e => { e.target.value = e.target.value.replace(/[^\d০-৯+\s-]/g, ''); });

  const submitBtn = $('#submitBtn');
  const btnOriginal = submitBtn.innerHTML;

  form.addEventListener('submit', e => {
    e.preventDefault();
    let firstInvalid = null;
    Object.keys(fields).forEach(key => {
      const msg = fields[key].validate(fields[key].el.value);
      setState(key, msg);
      if (msg && !firstInvalid) firstInvalid = key;
    });
    const areaSel = getArea();
    if (!firstInvalid && !areaSel) {
      setAreaError('অনুগ্রহ করে ডেলিভারি এলাকা নির্বাচন করুন');
      const f = areaField();
      f.classList.remove('shake'); void f.offsetWidth; f.classList.add('shake');
      $('input[name="area"]').focus();
      return;
    }
    if (firstInvalid) {
      const wrap = fields[firstInvalid].el.closest('.field');
      wrap.classList.remove('shake'); void wrap.offsetWidth; wrap.classList.add('shake');
      fields[firstInvalid].el.focus();
      return;
    }

    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span class="spinner"></span><span>অর্ডার প্রসেস হচ্ছে...</span>';

    const order = {
      id: 'TDC-' + Date.now().toString().slice(-6),
      type: 'single',
      product: DATA.slug,
      productName: DATA.en,
      variant: variant.id,
      variantLabel: variant.label,
      title: DATA.name,
      subtitle: variant.label + ' · ' + variant.note,
      lines: [],
      unitPrice: variant.price,
      qty,
      subtotal: variant.price * qty,
      deliveryArea: areaSel.id,
      deliveryLabel: areaSel.label,
      deliveryEta: areaSel.eta,
      deliveryCharge: areaSel.charge,
      total: variant.price * qty + areaSel.charge,
      name: fields.name.el.value.trim(),
      phone: toEn(fields.phone.el.value).replace(/[\s-]/g, '').replace(/^(\+?88)/, ''),
      address: fields.address.el.value.trim()
    };

    submitOrder(order)
      .then(() => showModal(order))
      .catch(() => alert('দুঃখিত, অর্ডারটি পাঠানো যায়নি। অনুগ্রহ করে আবার চেষ্টা করুন।'))
      .finally(() => {
        submitBtn.disabled = false;
        submitBtn.innerHTML = btnOriginal;
        update();
      });
  });

  /* ---------- Send order (demo) ----------
     আসল ব্যাকএন্ডের জন্য:
       return fetch('/api/orders', { method: 'POST', headers: { 'Content-Type': 'application/json' },
         body: JSON.stringify(order) }).then(r => { if (!r.ok) throw new Error('Order failed'); return r.json(); });
  */
  function submitOrder(order) {
    console.log('New order:', order);
    return new Promise(resolve => setTimeout(resolve, 1200));
  }

  /* ---------- Success modal ---------- */
  const modal = $('#successModal');
  let lastOrder = null;
  function showModal(o) {
    lastOrder = o;
    $('#mId').textContent = '#' + o.id;            // English digits
    $('#mName').textContent = o.name;
    $('#mPhone').textContent = o.phone;            // English digits
    $('#mPkg').textContent = o.variantLabel;
    $('#mQty').textContent = toBn(o.qty) + 'টি';
    $('#mTotal').textContent = fmtBn(o.total) + ' টাকা';
    modal.classList.add('open');
    modal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    setTimeout(() => $('#modalOk').focus(), 300);
  }
  function closeModal() {
    modal.classList.remove('open');
    modal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    form.reset();
    qty = 1; update();
    $$('.field', form).forEach(f => f.classList.remove('valid', 'invalid'));
    setAreaError(''); areaField().classList.remove('valid');
  }
  $('#modalClose').addEventListener('click', closeModal);
  // "ঠিক আছে" → পপআপ বন্ধ + ইনভয়েস (PDF) ডাউনলোড
  $('#modalOk').addEventListener('click', () => {
    const o = lastOrder;
    closeModal();
    if (o && window.TDCInvoice) window.TDCInvoice.download(o, { base: '../' });
  });
  modal.addEventListener('click', e => { if (e.target === modal) closeModal(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && modal.classList.contains('open')) closeModal(); });
})();
