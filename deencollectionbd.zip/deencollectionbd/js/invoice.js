/* ==========================================================================
   The Deen Collection — invoice.js
   অর্ডার সফল হলে ব্র্যান্ডেড A4 PDF ইনভয়েস তৈরি ও ডাউনলোড করে।
   --------------------------------------------------------------------------
   • কোনো বাইরের লাইব্রেরি লাগে না (অফলাইনেও কাজ করে)।
   • ব্রাউজারের canvas-এ ইনভয়েস আঁকা হয় (বাংলা যুক্তাক্ষর ঠিক থাকে), তারপর
     ছোট একটি PDF রাইটার দিয়ে A4 PDF বানানো হয়।
   • ব্যবহার:  TDCInvoice.download(order, { base: '' | '../' })
   • ব্যবসার যোগাযোগ তথ্য নিচের BUSINESS-এ বসান — ফাঁকা থাকলে ইনভয়েসে দেখাবে না।
   ========================================================================== */
(() => {
  'use strict';

  const BUSINESS = {
    name: 'The Deen Collection',
    nameBn: 'দ্য দীন কালেকশন',
    phone: '09658756148',
    whatsapp: '@deencollectionbd',
    email: 'info@deencollectionbd.com',
    website: 'deencollectionbd.com',
    facebook: 'facebook.com/deencollectionbd',
    address: 'Chandna Chowrasta, Gazipur Sadar, Gazipur-1702',
    hours: 'সকাল ০৮টা থেকে রাত ১০টা পর্যন্ত',
    policy: [
      'প্রোডাক্টে কোনো সমস্যা থাকলে বা ভুল প্রোডাক্ট ডেলিভারি পেলে, অনুগ্রহ করে ডেলিভারি ম্যানের সামনেই আমাদের জানান।',
      'আমরা ৩ থেকে ৭ কর্মদিবসের মধ্যে প্রোডাক্ট এক্সচেঞ্জ বা রিটার্ন সুবিধা দিয়ে থাকি। (শর্ত প্রযোজ্য)'
    ]
  };

  const C = {
    emerald: '#064e3b', emerald900: '#033b2c', emerald700: '#0f5132', emerald500: '#15805a', emerald50: '#ecf6f1',
    gold: '#d4af37', goldLight: '#ecd27a', goldDark: '#a8862a',
    ink: '#1b2420', gray: '#7b8079', gray300: '#d9dad3', gray100: '#f0f0eb', gray50: '#f7f7f4', red: '#c0392b'
  };
  const F = (w, s, fam = 'Hind Siliguri') => `${w} ${s}px '${fam}', 'Noto Sans Bengali', sans-serif`;
  const SERIF = 'Noto Serif Bengali';

  // A4 at design size 1240 × 1754, rendered at SCALE for a crisp print
  const W = 1240, H = 1754, SCALE = 1.7;

  const money = n => '৳ ' + Number(n).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const pad2 = n => String(n).padStart(2, '0');

  const loadImg = src => new Promise(res => {
    const im = new Image();
    im.onload = () => res(im);
    im.onerror = () => res(null);
    im.src = src;
  });

  async function ensureFonts() {
    if (!document.fonts || !document.fonts.load) return;
    const sample = 'অর্ডার ইনভয়েস Invoice 0123৳';
    await Promise.all([
      ...[400, 500, 600, 700].map(w => document.fonts.load(`${w} 20px 'Hind Siliguri'`, sample)),
      document.fonts.load(`700 20px '${SERIF}'`, sample)
    ]).catch(() => {});
  }

  /* ---------- drawing helpers ---------- */
  function rr(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }
  function text(ctx, s, x, y, font, color, align = 'left') {
    ctx.font = font; ctx.fillStyle = color; ctx.textAlign = align; ctx.textBaseline = 'alphabetic';
    ctx.fillText(s, x, y);
  }
  function wrap(ctx, s, maxW, font) {
    ctx.font = font;
    const words = String(s).split(/\s+/);
    const lines = []; let line = '';
    words.forEach(w => {
      const t = line ? line + ' ' + w : w;
      if (ctx.measureText(t).width > maxW && line) { lines.push(line); line = w; } else line = t;
    });
    if (line) lines.push(line);
    return lines;
  }
  function star(ctx, cx, cy, r) { // 8-point Islamic star
    ctx.beginPath();
    for (let i = 0; i < 16; i++) {
      const a = (Math.PI / 8) * i - Math.PI / 2;
      const rad = i % 2 === 0 ? r : r * 0.42;
      ctx.lineTo(cx + Math.cos(a) * rad, cy + Math.sin(a) * rad);
    }
    ctx.closePath();
  }

  /* ---------- the invoice ---------- */
  async function render(o, base) {
    await ensureFonts();
    const [logo, emblem] = await Promise.all([
      loadImg(base + 'assets/images/logo-horizontal.webp'),
      loadImg(base + 'assets/images/logo-main.webp')
    ]);

    const cv = document.createElement('canvas');
    cv.width = Math.round(W * SCALE); cv.height = Math.round(H * SCALE);
    const ctx = cv.getContext('2d');
    ctx.scale(SCALE, SCALE);
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, H);

    const M = 28;               // frame margin
    const L = 80, R = W - 80;   // content left/right

    /* watermark */
    if (emblem) {
      ctx.save(); ctx.globalAlpha = 0.045;
      const ew = 560, eh = ew * emblem.height / emblem.width;
      ctx.drawImage(emblem, (W - ew) / 2, 760, ew, eh);
      ctx.restore();
    }

    /* header band */
    const HB = 300;
    const g = ctx.createLinearGradient(0, M, W, HB);
    g.addColorStop(0, C.emerald); g.addColorStop(1, C.emerald900);
    ctx.fillStyle = g; ctx.fillRect(M, M, W - 2 * M, HB - M);
    // star pattern
    ctx.save();
    ctx.beginPath(); ctx.rect(M, M, W - 2 * M, HB - M); ctx.clip();
    ctx.strokeStyle = 'rgba(212,175,55,.13)'; ctx.lineWidth = 1.2;
    for (let y = M + 10; y < HB + 40; y += 64) for (let x = M + 10 + ((y / 64) % 2) * 32; x < W; x += 64) { star(ctx, x, y, 18); ctx.stroke(); }
    const glow = ctx.createRadialGradient(W - 220, 90, 10, W - 220, 90, 420);
    glow.addColorStop(0, 'rgba(212,175,55,.22)'); glow.addColorStop(1, 'rgba(212,175,55,0)');
    ctx.fillStyle = glow; ctx.fillRect(M, M, W, HB);
    ctx.restore();
    // gold rule under header
    const gr = ctx.createLinearGradient(M, 0, W - M, 0);
    gr.addColorStop(0, C.goldDark); gr.addColorStop(.5, C.goldLight); gr.addColorStop(1, C.goldDark);
    ctx.fillStyle = gr; ctx.fillRect(M, HB, W - 2 * M, 6);
    ctx.fillStyle = '#fff'; star(ctx, W / 2, HB + 3, 20); ctx.fill();
    ctx.fillStyle = C.gold; star(ctx, W / 2, HB + 3, 15); ctx.fill();

    if (logo) {
      const lh = 150, lw = lh * logo.width / logo.height;
      ctx.drawImage(logo, L - 10, 88, lw, lh);
    } else {
      text(ctx, BUSINESS.nameBn, L, 170, F(700, 48, SERIF), C.goldLight);
    }
    // INVOICE title
    const tg = ctx.createLinearGradient(R - 330, 0, R, 0);
    tg.addColorStop(0, C.goldLight); tg.addColorStop(1, C.gold);
    text(ctx, 'INVOICE', R, 158, F(700, 76), tg, 'right');
    text(ctx, 'ইনভয়েস · ক্যাশ মেমো', R, 200, F(500, 26), 'rgba(255,255,255,.82)', 'right');
    rr(ctx, R - 250, 222, 250, 40, 20); ctx.fillStyle = 'rgba(212,175,55,.16)'; ctx.fill();
    ctx.strokeStyle = 'rgba(212,175,55,.6)'; ctx.lineWidth = 1.2; ctx.stroke();
    text(ctx, 'No. ' + o.invoiceNo, R - 125, 249, F(600, 21), C.goldLight, 'center');

    /* meta cards */
    let y = 350;
    const meta = [
      ['অর্ডার আইডি', o.id],
      ['তারিখ', o.dateStr],
      ['সময়', o.timeStr],
      ['পেমেন্ট', 'Cash on Delivery']
    ];
    const gap = 16, cw = (R - L - gap * 3) / 4;
    meta.forEach(([k, v], i) => {
      const x = L + i * (cw + gap);
      rr(ctx, x, y, cw, 92, 14); ctx.fillStyle = C.gray50; ctx.fill();
      ctx.strokeStyle = C.gray100; ctx.lineWidth = 1.5; ctx.stroke();
      ctx.fillStyle = C.gold; ctx.fillRect(x, y + 18, 4, 56);
      text(ctx, k, x + 22, y + 36, F(500, 19), C.gray);
      text(ctx, v, x + 22, y + 72, F(700, 24), C.emerald);
    });

    /* bill to / from */
    y = 500;
    text(ctx, 'বিল প্রাপক', L, y, F(700, 19), C.goldDark);
    ctx.fillStyle = C.gold; ctx.fillRect(L, y + 10, 46, 3);
    text(ctx, o.name, L, y + 56, F(700, 32), C.ink);
    text(ctx, 'মোবাইল:  ' + o.phone, L, y + 94, F(500, 22), C.ink);
    const addr = wrap(ctx, 'ঠিকানা:  ' + o.address, 560, F(400, 21)).slice(0, 3);
    addr.forEach((ln, i) => text(ctx, ln, L, y + 130 + i * 32, F(400, 21), C.gray));
    let leftEnd = y + 130 + (addr.length - 1) * 32;
    if (o.deliveryLabel) {
      leftEnd += 40;
      text(ctx, 'ডেলিভারি এলাকা:  ' + o.deliveryLabel + (o.deliveryEta ? '  (আনুমানিক ' + o.deliveryEta + ')' : ''), L, leftEnd, F(600, 20), C.emerald);
    }

    const FX = 760;
    text(ctx, 'বিক্রেতা', FX, y, F(700, 19), C.goldDark);
    ctx.fillStyle = C.gold; ctx.fillRect(FX, y + 10, 46, 3);
    text(ctx, BUSINESS.nameBn, FX, y + 56, F(700, 30, SERIF), C.emerald);
    text(ctx, BUSINESS.name, FX, y + 90, F(600, 21), C.gray);
    let fy = y + 124;
    if (BUSINESS.address) wrap(ctx, BUSINESS.address, R - FX, F(400, 19)).forEach(ln => { text(ctx, ln, FX, fy, F(400, 19), C.gray); fy += 28; });
    if (BUSINESS.phone) { text(ctx, 'হেল্পলাইন:  ' + BUSINESS.phone, FX, fy, F(600, 20), C.ink); fy += 30; }
    if (BUSINESS.hours) { text(ctx, BUSINESS.hours, FX, fy, F(400, 18), C.gray); fy += 30; }
    // status pill
    const sy = fy + 14;
    rr(ctx, FX, sy - 26, 330, 40, 20); ctx.fillStyle = C.emerald50; ctx.fill();
    ctx.fillStyle = C.emerald500; ctx.beginPath(); ctx.arc(FX + 22, sy - 6, 6, 0, Math.PI * 2); ctx.fill();
    text(ctx, 'অর্ডার গৃহীত — কনফার্মেশনের অপেক্ষায়', FX + 38, sy + 1, F(600, 19), C.emerald);
    const billEnd = Math.max(leftEnd, sy + 14);

    /* items table */
    y = Math.max(720, billEnd + 46);
    const col = { no: L + 24, desc: L + 80, qty: 790, unit: 970, total: R - 24 };
    rr(ctx, L, y, R - L, 58, 12); ctx.fillStyle = C.emerald; ctx.fill();
    const th = F(600, 20);
    text(ctx, '#', col.no, y + 37, th, C.goldLight);
    text(ctx, 'পণ্যের বিবরণ', col.desc, y + 37, th, '#fff');
    text(ctx, 'পরিমাণ', col.qty, y + 37, th, '#fff', 'center');
    text(ctx, 'একক মূল্য', col.unit, y + 37, th, '#fff', 'right');
    text(ctx, 'মোট', col.total, y + 37, th, '#fff', 'right');
    y += 58;

    // row
    const items = o.lines || [];
    const half = Math.ceil(items.length / 2);
    const rowH = 96 + (items.length ? 40 + half * 34 : 0);
    ctx.fillStyle = '#fff'; ctx.fillRect(L, y, R - L, rowH);
    ctx.strokeStyle = C.gray100; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(L, y + rowH); ctx.lineTo(R, y + rowH); ctx.stroke();
    text(ctx, '01', col.no, y + 50, F(600, 22), C.gray);
    text(ctx, o.title, col.desc, y + 50, F(700, 28), C.ink);
    if (o.subtitle) text(ctx, o.subtitle, col.desc, y + 82, F(400, 19), C.gray);
    text(ctx, String(o.qty), col.qty, y + 50, F(700, 24), C.ink, 'center');
    text(ctx, money(o.unitPrice), col.unit, y + 50, F(500, 22), C.ink, 'right');
    text(ctx, money(o.unitPrice * o.qty), col.total, y + 50, F(700, 24), C.emerald, 'right');

    if (items.length) {
      let iy = y + 126;
      text(ctx, 'প্যাকেজে যা যা থাকছে:', col.desc, iy, F(600, 19), C.goldDark);
      iy += 36;
      const colW = Math.floor((R - col.desc) / 2);   // two columns across the full row
      items.forEach((it, i) => {
        const cx = col.desc + (i >= half ? colW : 0);
        const cy = iy + (i % half) * 34;
        if (it.gift) {
          ctx.fillStyle = C.gold; star(ctx, cx + 7, cy - 7, 8); ctx.fill();
        } else {
          ctx.strokeStyle = C.emerald500; ctx.lineWidth = 2.6; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
          ctx.beginPath(); ctx.moveTo(cx, cy - 8); ctx.lineTo(cx + 5, cy - 3); ctx.lineTo(cx + 14, cy - 14); ctx.stroke();
        }
        let label = it.name;
        ctx.font = F(400, 19);
        while (ctx.measureText(label).width > colW - (it.gift ? 100 : 40) && label.length > 4) label = label.slice(0, -2);
        if (label !== it.name) label = label.trim() + '…';
        text(ctx, label, cx + 26, cy, F(400, 19), C.ink);
        if (it.gift) {
          const tw = ctx.measureText(label).width;
          rr(ctx, cx + 34 + tw, cy - 21, 48, 26, 13); ctx.fillStyle = C.gold; ctx.fill();
          text(ctx, 'ফ্রি', cx + 58 + tw, cy - 2, F(700, 15), C.emerald900, 'center');
        }
      });
    }
    y += rowH + 36;

    /* totals (right) */
    const TX = 700, TW = R - TX;
    const rows = [];
    if (o.mrp && o.mrp > o.unitPrice) {
      rows.push(['নিয়মিত মূল্য (আলাদা কিনলে)', money(o.mrp * o.qty), C.gray]);
      rows.push(['কম্বো ছাড়', '− ' + money((o.mrp - o.unitPrice) * o.qty), C.red]);
    }
    const sub = o.subtotal != null ? o.subtotal : o.unitPrice * o.qty;
    rows.push(['সাবটোটাল', money(sub), C.ink]);
    if (o.deliveryCharge != null) rows.push([`ডেলিভারি চার্জ (${o.deliveryLabel})`, money(o.deliveryCharge), C.ink]);
    let ty = y;
    rows.forEach(([k, v, col2]) => {
      text(ctx, k, TX, ty + 22, F(500, 20), C.gray);
      text(ctx, v, R, ty + 22, F(600, 21), col2, 'right');
      ty += 42;
    });
    ty += 6;
    const tb = ctx.createLinearGradient(TX, 0, R, 0);
    tb.addColorStop(0, C.emerald700); tb.addColorStop(1, C.emerald900);
    rr(ctx, TX - 20, ty, TW + 20, 80, 16); ctx.fillStyle = tb; ctx.fill();
    ctx.fillStyle = C.gold; ctx.fillRect(TX - 20, ty + 16, 5, 48);
    text(ctx, 'সর্বমোট', TX + 6, ty + 51, F(600, 24), '#fff');
    text(ctx, money(o.total), R - 22, ty + 54, F(700, 36), C.goldLight, 'right');
    const totalsEnd = ty + 80;

    /* payment + savings (left) */
    const PW = 560;
    rr(ctx, L, y, PW, 118, 16); ctx.fillStyle = C.gray50; ctx.fill();
    ctx.strokeStyle = C.gray300; ctx.setLineDash([6, 5]); ctx.lineWidth = 1.5; ctx.stroke(); ctx.setLineDash([]);
    // cash icon
    rr(ctx, L + 24, y + 32, 64, 44, 8); ctx.strokeStyle = C.emerald500; ctx.lineWidth = 3; ctx.stroke();
    ctx.beginPath(); ctx.arc(L + 56, y + 54, 10, 0, Math.PI * 2); ctx.stroke();
    text(ctx, 'পেমেন্ট পদ্ধতি: ক্যাশ অন ডেলিভারি', L + 108, y + 52, F(700, 22), C.emerald);
    text(ctx, 'পণ্য হাতে পেয়ে দেখে তারপর মূল্য পরিশোধ করুন।', L + 108, y + 86, F(400, 19), C.gray);

    if (o.mrp && o.mrp > o.unitPrice) {
      const sy2 = y + 140;
      const sg = ctx.createLinearGradient(L, 0, L + PW, 0);
      sg.addColorStop(0, '#fdf8e8'); sg.addColorStop(1, '#f6e7b8');
      rr(ctx, L, sy2, PW, 76, 16); ctx.fillStyle = sg; ctx.fill();
      ctx.strokeStyle = C.gold; ctx.lineWidth = 1.5; ctx.stroke();
      ctx.fillStyle = C.gold; star(ctx, L + 46, sy2 + 38, 20); ctx.fill();
      text(ctx, 'অভিনন্দন! এই অর্ডারে আপনি সাশ্রয় করেছেন', L + 82, sy2 + 33, F(500, 19), C.ink);
      text(ctx, money((o.mrp - o.unitPrice) * o.qty), L + 82, sy2 + 63, F(700, 26), C.emerald);
    }

    /* footer: thanks + policy */
    const BBH = 96, BB = H - M - BBH;
    const nPol = (BUSINESS.policy || []).length;
    const fullNeed = 44 + 122 + 50 + nPol * 30 + 16;          // spacious layout
    const compact = BB - totalsEnd < fullNeed;                  // long item lists → tighter footer
    const K = compact
      ? { gap: 24, title: 46, tSize: 30, txt: 76, pol: 92, head: 30, first: 58, lh: 27 }
      : { gap: 44, title: 58, tSize: 38, txt: 96, pol: 122, head: 34, first: 66, lh: 30 };
    const fyTop = compact ? totalsEnd + K.gap : Math.max(totalsEnd + K.gap, BB - (K.pol + 50 + nPol * K.lh + 30));
    ctx.strokeStyle = C.gray100; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(L, fyTop); ctx.lineTo(R, fyTop); ctx.stroke();
    ctx.fillStyle = C.gold; star(ctx, W / 2, fyTop, 10); ctx.fill();
    text(ctx, 'জাযাকাল্লাহু খাইরান!', W / 2, fyTop + K.title, F(700, K.tSize, SERIF), C.emerald, 'center');
    text(ctx, 'দ্য দীন কালেকশন থেকে কেনাকাটার জন্য আপনাকে আন্তরিক ধন্যবাদ। শীঘ্রই আমাদের প্রতিনিধি ফোন করে অর্ডার কনফার্ম করবেন।',
      W / 2, fyTop + K.txt, F(400, compact ? 17 : 18), C.gray, 'center');

    if (BUSINESS.policy && BUSINESS.policy.length) {
      const py = fyTop + K.pol, ph = K.first - 14 + nPol * K.lh;
      rr(ctx, L, py, R - L, ph, 14); ctx.fillStyle = C.gray50; ctx.fill();
      ctx.strokeStyle = C.gray300; ctx.setLineDash([6, 5]); ctx.lineWidth = 1.3; ctx.stroke(); ctx.setLineDash([]);
      text(ctx, 'রিটার্ন ও এক্সচেঞ্জ নীতি', L + 24, py + K.head, F(700, 19), C.goldDark);
      BUSINESS.policy.forEach((ln, i) => {
        const ly = py + K.first + i * K.lh;
        ctx.fillStyle = C.emerald500; ctx.beginPath(); ctx.arc(L + 30, ly - 6, 4, 0, Math.PI * 2); ctx.fill();
        text(ctx, ln, L + 46, ly, F(400, 18), C.ink);
      });
    }

    // bottom band: contacts + note
    ctx.fillStyle = C.emerald900; ctx.fillRect(M, BB, W - 2 * M, BBH);
    ctx.fillStyle = gr; ctx.fillRect(M, BB, W - 2 * M, 3);
    const contacts = [
      BUSINESS.phone && ['হেল্পলাইন', BUSINESS.phone],
      BUSINESS.whatsapp && ['WhatsApp', BUSINESS.whatsapp],
      BUSINESS.email && ['', BUSINESS.email],
      BUSINESS.website && ['', BUSINESS.website],
      BUSINESS.facebook && ['', BUSINESS.facebook]
    ].filter(Boolean);
    if (contacts.length) {
      // measure, then lay out centered with gold separators
      let size = 18; const sep = 30;
      const widthOf = () => contacts.reduce((wsum, [k, v]) => {
        ctx.font = F(500, size); const kw = k ? ctx.measureText(k + ': ').width : 0;
        ctx.font = F(600, size); return wsum + kw + ctx.measureText(v).width;
      }, 0) + sep * (contacts.length - 1);
      while (widthOf() > R - L && size > 13) size--;
      let cx = (W - widthOf()) / 2;
      contacts.forEach(([k, v], i) => {
        if (k) { text(ctx, k + ': ', cx, BB + 40, F(500, size), 'rgba(255,255,255,.7)'); ctx.font = F(500, size); cx += ctx.measureText(k + ': ').width; }
        text(ctx, v, cx, BB + 40, F(600, size), C.goldLight); ctx.font = F(600, size); cx += ctx.measureText(v).width;
        if (i < contacts.length - 1) { ctx.fillStyle = C.gold; ctx.beginPath(); ctx.arc(cx + sep / 2, BB + 34, 2.6, 0, Math.PI * 2); ctx.fill(); cx += sep; }
      });
    }
    ctx.fillStyle = 'rgba(255,255,255,.1)'; ctx.fillRect(L, BB + 56, R - L, 1);
    text(ctx, 'এটি একটি কম্পিউটারে তৈরি ইনভয়েস — কোনো স্বাক্ষরের প্রয়োজন নেই।', L, BB + 82, F(400, 16), 'rgba(255,255,255,.65)');
    text(ctx, 'Generated: ' + o.dateStr + ', ' + o.timeStr, R, BB + 82, F(500, 16), 'rgba(236,210,122,.85)', 'right');

    /* frame */
    ctx.strokeStyle = C.gold; ctx.lineWidth = 2.5; ctx.strokeRect(M, M, W - 2 * M, H - 2 * M);
    ctx.strokeStyle = 'rgba(212,175,55,.45)'; ctx.lineWidth = 1; ctx.strokeRect(M - 10, M - 10, W - 2 * M + 20, H - 2 * M + 20);
    [[M, M], [W - M, M], [M, H - M], [W - M, H - M]].forEach(([cx, cy]) => {
      ctx.fillStyle = '#fff'; star(ctx, cx, cy, 13); ctx.fill();
      ctx.fillStyle = C.gold; star(ctx, cx, cy, 10); ctx.fill();
    });

    return cv;
  }

  /* ---------- minimal PDF writer: one full-page JPEG on A4 ---------- */
  function canvasToPdf(cv) {
    const jpg = atob(cv.toDataURL('image/jpeg', 0.9).split(',')[1]);
    const img = new Uint8Array(jpg.length);
    for (let i = 0; i < jpg.length; i++) img[i] = jpg.charCodeAt(i);

    const enc = s => new TextEncoder().encode(s);
    const PW = 595.28, PH = 841.89;
    const content = `q ${PW} 0 0 ${PH} 0 0 cm /Im0 Do Q`;
    const chunks = []; const offsets = []; let len = 0;
    const push = b => { chunks.push(b); len += b.length; };
    const obj = (n, body) => { offsets[n] = len; push(enc(`${n} 0 obj\n${body}\nendobj\n`)); };

    push(enc('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n'));
    obj(1, '<< /Type /Catalog /Pages 2 0 R >>');
    obj(2, '<< /Type /Pages /Kids [3 0 R] /Count 1 >>');
    obj(3, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${PW} ${PH}] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>`);
    offsets[4] = len;
    push(enc(`4 0 obj\n<< /Type /XObject /Subtype /Image /Width ${cv.width} /Height ${cv.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${img.length} >>\nstream\n`));
    push(img);
    push(enc('\nendstream\nendobj\n'));
    obj(5, `<< /Length ${content.length} >>\nstream\n${content}\nendstream`);
    obj(6, `<< /Title (Invoice) /Producer (The Deen Collection) /CreationDate (D:${new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14)}) >>`);

    const xref = len;
    let x = 'xref\n0 7\n0000000000 65535 f \n';
    for (let i = 1; i <= 6; i++) x += String(offsets[i]).padStart(10, '0') + ' 00000 n \n';
    push(enc(x + `trailer\n<< /Size 7 /Root 1 0 R /Info 6 0 R >>\nstartxref\n${xref}\n%%EOF`));
    return new Blob(chunks, { type: 'application/pdf' });
  }

  /* ---------- toast ---------- */
  function toast(msg, ok) {
    let t = document.getElementById('tdcToast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'tdcToast'; t.className = 'tdc-toast'; t.setAttribute('role', 'status');
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.classList.toggle('ok', !!ok);
    t.classList.add('show');
    clearTimeout(t._h);
    t._h = setTimeout(() => t.classList.remove('show'), ok ? 3200 : 6000);
  }

  /* ---------- public API ---------- */
  async function download(order, opts = {}) {
    const base = opts.base || '';
    const d = new Date();
    const mon = d.toLocaleString('en-US', { month: 'short' });
    const o = Object.assign({}, order, {
      invoiceNo: 'INV-' + String(order.id).replace(/^TDC-/, ''),
      dateStr: `${pad2(d.getDate())} ${mon} ${d.getFullYear()}`,
      timeStr: d.toLocaleString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true })
    });
    toast('আপনার ইনভয়েস তৈরি হচ্ছে…');
    try {
      const cv = await render(o, base);
      const blob = canvasToPdf(cv);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = `The-Deen-Collection-Invoice-${o.id}.pdf`;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 60000);
      toast('✓ ইনভয়েস ডাউনলোড হয়েছে', true);
    } catch (err) {
      console.error('Invoice error:', err);
      toast('দুঃখিত, ইনভয়েস তৈরি করা যায়নি। আবার চেষ্টা করুন।');
    }
  }

  window.TDCInvoice = { download, render, canvasToPdf, BUSINESS };
})();
