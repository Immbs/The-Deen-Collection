# Dev server with caching disabled (so CSS/JS changes always show up)
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
class H(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Cache-Control', 'no-store, must-revalidate')
        super().end_headers()
ThreadingHTTPServer(('0.0.0.0', 8080), H).serve_forever()
